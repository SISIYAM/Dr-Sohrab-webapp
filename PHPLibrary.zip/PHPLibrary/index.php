<?php
require_once 'PHPLibrary/UddoktaPay.php';

// $app_key ='kYfLMvjge8RK42IldQs2Mzt3tc';
// $app_secret ='OUKQ1VMhVXbM16qQv1yifmBZJg9FglGLcQnkxN69ZKbD4oCg7VtQ';
// $username ='01650207886';
// $password ='^R0rA}1}8tz';
// $base_url = 'https://tokenized.sandbox.bka.sh';

$apiKey = "5023231de524372ea3b6d3d0c1cd6e3295f7c366";
$apiBaseURL = "https://secure.asgcompressednote.com/api/checkout-v2";
$uddoktaPay = new UddoktaPay($apiKey, $apiBaseURL);



// Example request data for initializing a payment
$requestData = [
    'full_name'     => $fname,
    'email'         => $email,
    'amount'        => $price,
    'metadata'      => [
        'example_metadata_key' => "example_metadata_value",
        'user_id' => $user_id,
        'ip_address' => $ipAddr,
        'promo_code' => $promo,
        'customer_number' => $phn,
        // ... Add more key-value pairs for dynamic metadata ...
    ],
    'redirect_url'  => 'https://secure.asgcompressednote.com/payment_success.php',
    'return_type'   => 'GET',
    'cancel_url'    => 'cancel.php',
    'webhook_url'   => 'ipn.php',
];

try {
    $paymentUrl = $uddoktaPay->initPayment($requestData);
    ?>
        <script>
            window.location.replace("<?php echo $paymentUrl; ?>");
            // aler("TRY");
        </script>
    <?php
    header('Location: ' . $paymentUrl); // Redirect user
    
} catch (Exception $e) {
    ?>
    <script>
        // alert("<?=$e->getMessage()?>");
        alert("Under Maintenance...");
        </script>
    <?php
    echo "Initialization Error: " . $e->getMessage();
}