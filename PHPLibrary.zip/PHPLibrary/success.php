<?php
require_once 'UddoktaPay.php';

$apiKey = "5023231de524372ea3b6d3d0c1cd6e3295f7c366"; // API KEY
$apiBaseURL = "https://secure.asgcompressednote.com/api/checkout-v2"; // API URL
$uddoktaPay = new UddoktaPay($apiKey, $apiBaseURL);

// Simulating getting the invoice ID from payment success page (GET or POST)
$invoiceId = $_GET['invoice_id']; // Assuming you receive it via GET or POST

try {
    // Verify payment
    $response = $uddoktaPay->verifyPayment($invoiceId);

    print_r($response); // Display the verification response
} catch (Exception $e) {
    echo "Verification Error: " . $e->getMessage();
}